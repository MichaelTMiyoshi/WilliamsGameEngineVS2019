#pragma once

const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;